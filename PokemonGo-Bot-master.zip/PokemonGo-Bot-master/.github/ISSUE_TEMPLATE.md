######################## RULES. READ BEFORE POSTING! ########################

-> DONT OPEN A NEW ISSUE IF YOU DIDNT SEARCH YOUR PROBLEM IN THE ISSUES!

-> DONT OPEN A NEW ISSUE IF YOUR ISSUE GOT ANSWERED PERVIOUSLY!

-> DONT OPEN A NEW ISSUE IF YOUR "ISSUE" IS A QUESTION/SUGGESTION!

-> DONT OPEN A NEW ISSUE IF YOU DONT USE THE NEWEST VERSION!

If you do not respect them, your issue gets closed without any comment

#########################################################################

Describe your problem!

Add a screenshot!

Choose a good title!

Dont forget to delete this template!

Post.
