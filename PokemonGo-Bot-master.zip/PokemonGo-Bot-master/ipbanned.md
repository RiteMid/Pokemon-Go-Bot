<h1>What should i do if i got IP Banned?</h1>
<h4>1. The easiest way is to restart your router which works in like 90%.</h4>
<h4>2. The other way is to use a Proxy. The Proxy needs to be HTTPS.</h4>
<h4>WTF this dont help? Then read it again.</h4>
<br><br>
<h1>How can i check if i got IP Banned?</h1>
<h4>1. You wont find any Pokestops. Even if you change your location</h4>
